# Type & Layout

## Typography

Use **Inter** for all UI and display. Fallback: `system-ui, sans-serif`. Inter is
a variable font — use `font-variation-settings` to set weight, not `font-weight`.

```css
/* Correct */
font-variation-settings: 'wght' 600;

/* Wrong */
font-weight: 600;
```

Do not use Open Sans. It exists in legacy parts of the design file but is not
part of the G2RS system. Inter only.

Weights: 400 body, 500 most UI labels and inputs, 600 headings/buttons/table
headers/emphasized values, 700 display.

The UI baseline is **14px / 20px line-height** — the default for table cells,
labels, buttons, and menu items. Apply `-0.02em` tracking on sizes ≥24px.

| Style | Size / line-height | Weight |
|---|---|---|
| Display lg | 48 / 60 | 600 |
| Display xs | 24 / 32 | 600 |
| Text xl | 20 / 30 | 400–600 |
| Text lg | 18 / 28 | 400–600 |
| Text md | 16 / 24 | 400 body, 500 inputs |
| Text sm | 14 / 20 | 500–600 (UI default) |
| Text xs | 12 / 18 | 500–600 (chips, captions) |

**Off-scale sizes — never use:**
- 9px — minimum is 12px
- 11px — use 12px
- 13px — use 12px or 14px
- 15px — use 14px or 16px
- 22px — use 20px or 24px
- 42px — use 48px (display-lg)

Table row title: 14px semibold `#181D27`. Sub-label (MID • MCC): 13px `#717680`.
Render IDs and codes in a muted, technical style:
`4567890 • 5912 — Drug Stores And Pharmacies`.

## Spacing

Use a 4px base grid. Rhythm: 4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48 / 80.
Do not use off-grid values. Do not hardcode pixel values when a layout token
exists.

The one documented exception: `6px` is permitted for tight insets (e.g. tag
internal padding) where 4px is too tight and 8px is too loose.

- Table cell padding: `16px 24px` (first cell: 24px left)
- Card padding: `24px`
- Toolbar / filter row padding: `16px 24px`
- Left-nav item padding: `16px` (symmetric — not 17px)

**Off-grid values — never use:**
- `10px` gap — use `8px` or `12px`
- `17px` padding — use `16px`
- `28px` — use `24px` or `32px`
- `20px` padding on filter bar — use `24px`

## Radius

| Context | Radius |
|---|---|
| Tags / rectangular badges | **6px** |
| Inputs, buttons, nav items, dropdowns | **8px** |
| Toasts / notifications | **12px** |
| Cards, modals | **16px** |
| Pills, toggles, progress bars, avatars | **full (9999px)** |

Nothing sharp (0px). Nothing at 10px, 20px, or 24px — these are off-scale.
`24px` on a badge is off-scale; use `16px` or `full`.

## Elevation

Shadows are soft, low-opacity, and neutral (`rgba(10,13,18,…)`). Never colored.
Always write composite shadows as a single `box-shadow` declaration.

- xs: `0 1px 2px rgba(10,13,18,.05)` — buttons, inputs
- sm: `0 1px 3px rgba(10,13,18,.10)` — resting cards
- lg: `0 12px 16px -4px rgba(10,13,18,.08)` — dropdowns, popovers, drawer
- 2xl: `0 24px 48px -12px rgba(10,13,18,.18)` — modals

Focus ring: `0 0 0 4px rgba(20,71,230,.24)`. Error fields use a red ring instead.

## Iconography

Use Unicons line style only — package `@iconscout/react-unicons`. Never use
`@ant-design/icons` or `lucide-react` for UI elements. Icons are SVG components,
monochrome, rendered at 16–20px in UI. Pass `color="currentColor"` so they
inherit text color. Pass `size={16}` or `size={20}`.

Import icons individually by path for best tree-shaking:

```tsx
import UilSearch from '@iconscout/react-unicons/icons/uil-search';
import UilPlus from '@iconscout/react-unicons/icons/uil-plus';
import UilAngleDown from '@iconscout/react-unicons/icons/uil-angle-down';
import UilSetting from '@iconscout/react-unicons/icons/uil-setting';
import UilImport from '@iconscout/react-unicons/icons/uil-import';
import UilFilter from '@iconscout/react-unicons/icons/uil-filter';
import UilExclamationTriangle from '@iconscout/react-unicons/icons/uil-exclamation-triangle';
import UilCheckCircle from '@iconscout/react-unicons/icons/uil-check-circle';
import UilEdit from '@iconscout/react-unicons/icons/uil-edit';
import UilTimes from '@iconscout/react-unicons/icons/uil-times';
import UilQuestionCircle from '@iconscout/react-unicons/icons/uil-question-circle';
import UilEllipsisV from '@iconscout/react-unicons/icons/uil-ellipsis-v';
import UilArrowUp from '@iconscout/react-unicons/icons/uil-arrow-up';
import UilArrowDown from '@iconscout/react-unicons/icons/uil-arrow-down';
import UilUpload from '@iconscout/react-unicons/icons/uil-upload';
import UilUser from '@iconscout/react-unicons/icons/uil-user';
```

Usage:

```tsx
<UilSearch size={16} color="currentColor" />
<UilPlus size={16} color="currentColor" />
```

All icons use the `Uil` prefix (Unicons line). Do not use `Uis` (solid),
`Uit` (thinline), or `Uim` (monochrome) prefixes.

No emoji. No unicode-symbol icons. Show status with color and a label, optionally
a leading dot — never an emoji.