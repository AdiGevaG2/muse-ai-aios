# Color

Use only these tokens. Do not introduce new hex values. Color carries meaning —
risk, status, category, interaction. Never use color for mood or decoration.

## Brand — G2RS Blue

Use brand blue for interaction only: primary buttons, links, active tab, current
selection, focus ring, and progress fill. Do not use it as a surface or
background fill except where a token below specifies a tint.

| Token | Hex | Use |
|---|---|---|
| brand-50 | `#E2E8FF` | selected row / chip background |
| brand-100 | `#D0DAFF` | hover tint |
| brand-300 | `#9AA8FF` | borders on tinted chips |
| brand-500 | `#3360FC` | reserved |
| **brand-600** | **`#1447E6`** | **primary buttons, links, active tab, selection, focus, progress fill** |
| brand-700 | `#1B43B7` | primary hover, link hover |
| brand-800 | `#193A88` | pressed |

**Purple is deprecated and must never be used.** The design library contains a
legacy purple brand ramp (`brand-600 = #7B56D9`). Ignore it entirely. The
canonical brand color is blue `#1447E6`. If a token resolves to any purple value,
do not use it — use `brand-600 #1447E6` instead.

## Neutrals — light mode only

Dark mode is not supported. Do not generate dark mode variants, dark surfaces, or
dark-themed components under any circumstances.

## Neutrals

| Role | Hex | CSS token |
|---|---|---|
| Text primary | `#181D27` | `--color-text-primary-900` |
| Text secondary | `#414651` | `--color-text-secondary-700` |
| Text tertiary / labels | `#535862` | `--color-text-tertiary-600` |
| Placeholder / muted | `#717680` | `--color-text-quaternary` |
| Disabled text | `#A4A7AE` | — |
| Border (strong) | `#D5D7DA` | `--color-border-primary` |
| Border (subtle) / dividers | `#E9EAEB` | `--color-border-secondary` |
| Page background | `#F8F9FD` | — |
| Card / surface | `#FFFFFF` | — |

Build screens as white cards on a `#F8F9FD` page. Create hierarchy with surface
and border, not with color. Always use the CSS token when one exists.

**Off-palette values — never use these:**

These values exist in legacy parts of the design file and must not appear in any
new generated screen:

| Off-palette value | Replace with |
|---|---|
| `#1D1D1D` (near-black text) | `#181D27` (text-primary) |
| `#747474` (gray text) | `#717680` (text-quaternary) |
| `#000000` (pure black as text) | `#181D27` (text-primary) |
| `#E7E7E7` (near gray-200 border) | `#E9EAEB` (border-secondary) |
| `#E5E7EB` (near gray-200 border) | `#E9EAEB` (border-secondary) |
| `rgba(0,0,0,0.1)` (border) | `#E9EAEB` (border-secondary) |
| `#F9FAFB` (near page bg) | `#F8F9FD` (page background) |
| `#F7F5F7` (off-white surface) | `#FAFAFA` (gray-50) |

`#E9EAEB` is the one and only border-secondary value. Do not approximate it.

## Risk & semantic (outlined pills)

Risk is the core data type. Always render risk levels as outlined pills:
`50` background, `300` border, `600`–`700` text.

| Meaning | bg-50 | border-200 | text-600 |
|---|---|---|---|
| Critical | `#FEF3F2` | `#FECDCA` | `#D92D20` |
| High / Warning | `#FFFAEB` | `#FEDF89` | `#DC6803` |
| Medium | `#FFFAEB` | `#FEDF89` | `#CA8504` |
| Low / Success | `#ECFDF3` | `#ABEFC6` | `#079455` |

Reserve these colors for risk and status only. Do not use them for general
emphasis or decoration.

**Off-palette reds — never use:**
- `#BF1313` — replace with `#D92D20` (error-600)
- `#E54A59` — replace with `#D92D20` (error-600)

## Category chips

Use soft tinted pills for merchant category tags (Alcohol, CBD Oil, Gambling,
Nutraceuticals, …): `50` background, `200` border, `700` text, across the full
accent palette (blue, indigo, purple, pink, orange, success). When categories
overflow, collapse the rest into a gray chip: `+N`.

Note: purple is permitted for category chips only, as an accent color. It is
never permitted as a brand or interactive color.

## Active nav tint

Active left-nav item background: `#EFF8FF` (blue-50). Do not use `#EFF6FF` —
it is an off-palette near-duplicate. Use `#EFF8FF` only.

## Gradients — these surfaces only

Gradients are allowed in exactly three places. Never anywhere else.

- Logo mark: `linear-gradient(90deg, #FF4E32 -15%, #FF7E06 32%, #FF8500 43%, #FFC635 101%)`
- Login / marketing backdrop: `linear-gradient(228deg, #03045E 1%, #832AD0 104%)`
- Logo wordmark navy: `#000457`

Do not apply gradients to in-app chrome — tables, cards, nav, toolbars, buttons.
Do not use colored shadows.