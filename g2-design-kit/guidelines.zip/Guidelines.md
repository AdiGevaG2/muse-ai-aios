# G2 Risk Solutions — Make Kit Guidelines

This is the root guidelines file. Read it first. It defines the product, the
global rules that apply to every screen, and where to find detailed rules for
specific parts of the system.

## What G2RS is

G2RS is a B2B SaaS compliance platform. Analysts on payment-risk teams use it to
scan online merchants and review compliance violations called **findings**. The
work is repetitive, high-volume, and serious. Build clean, neutral, data-dense,
information-first interfaces. Color carries meaning — risk, status, category —
never mood. Nothing is decorative.

The visual foundation is Untitled UI, re-skinned in G2RS blue (`#1447E6`).
Surfaces are white cards on a near-white page, bordered and lightly shadowed.
Type is **Inter** throughout.

## Global rules (apply everywhere)

- Every screen must be wrapped in `<ConfigProvider theme={g2rsTheme}>` imported
  from `src/theme.ts`. This is the only way to make antd use G2RS colors. Chat
  instructions about colors and CSS class overrides cannot override antd's theme
  system — only ConfigProvider can. See `setup.md` for the full theme constant.
- Use only defined tokens for color, type, spacing, radius, and shadow. Do not
  introduce new hex values, font sizes, or radii.
- Keep in-app chrome flat. No gradient backgrounds on tables, cards, nav, or
  toolbars. Gradients appear only on the logo mark and the login/marketing
  backdrop. See `foundations/color.md`.
- Use color only when it means something. Default UI is neutral gray + brand blue
  for interaction. Red/orange/yellow/green are reserved for risk and status.
- No emoji. No unicode-symbol icons. Status is shown with color + a text label,
  optionally a leading dot. Icons are Unicons line style only from
  `@iconscout/react-unicons`. All icon components use the `Uil` prefix.
- Default UI text is 14px. Do not use text below 12px. Do not use placeholder
  gray for real content.
- Motion is restrained: 120–160ms ease on hover, press, and progress. No bounce,
  no looping or decorative animation.
- Icon buttons are frameless — no background, no border, no wrapping container
  at rest. Transparent by default, `#F5F5F5` background on hover only.

## Reading order

Read in this sequence before writing any code:

1. This file (`Guidelines.md`) — product brief, global rules, file map
2. **`setup.md`** — ConfigProvider theme, stack, CSS imports, antd component
   classes, layout model, token format quirks. Read before touching any code.
3. `foundations/color.md` — when choosing any color
4. `foundations/type-and-layout.md` — when setting type, spacing, radius, shadow
5. `components/components.md` — before building any component
6. `patterns/voice-motion-states.md` — when writing copy or defining states

Read foundation and component files on demand — only the ones relevant to what
is being built. Do not load all files at once.

## Task routing — read only what the task needs

| Task | Files to read |
|---|---|
| Any screen | Guidelines.md → setup.md |
| Choosing a color | + foundations/color.md |
| Setting type, spacing, shadow | + foundations/type-and-layout.md |
| Building any component | + components/components.md |
| Writing copy or defining states | + patterns/voice-motion-states.md |
| Full screen with components | All files |

Do not open files not listed as relevant to the current task.

## Remaining gap

- **Data visualization** — no chart colors, types, or axis styling are defined.
  Until this is specified, do not generate charts or graphs. Use a table or
  stat-card instead.