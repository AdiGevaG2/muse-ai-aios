# Components

Use G2RS antd components with their G2RS class overrides. The rules below define
how and when to use each. Do not rebuild these from scratch with raw HTML.
See `setup.md` for the full antd class reference.

---

## Buttons

Height 36px, radius 8px, `font-variation-settings: 'wght' 600`, 14px label,
icon-to-label gap 6–8px. Always include `className="ant-g2-button"`.

One button family only. Do not use MKV buttons or legacy button components.

- **Primary** — `type="primary" variant="solid"`. Background `#1447E6`, white
  text; hover `#1B43B7`. One primary per view.
- **Secondary-gray** — `type="default" variant="outlined"`. White background,
  `#414651` text, `#D5D7DA` border; hover `#F9F9F9`.
- **Tertiary** — `type="default" variant="text"`. Transparent, gray-600 text.
- **Link** — `type="primary" variant="link"`. No padding, `#1447E6` text.
- **Destructive** — `type="primary" variant="solid" danger`. `#D92D20` background.
  Do not use a separate destructive component — use the `danger` prop.
- **Disabled** — `disabled` prop. Opacity 0.5, no shadow.
- **Icon button** — 36×36px square, same hierarchy variants.

Example icon button (frameless):

```tsx
import UilSetting from '@iconscout/react-unicons/icons/uil-setting';

<Button type="text" className="ant-g2-button" icon={<UilSetting size={16} color="currentColor" />} />
```

All buttons use radius 8px. Do not use radius 6px on any button variant.

---

## Inputs & selects

Always include `className="ant-g2-input"` on Input, `className="ant-g2-select"`
on Select. Height 36px, 8px radius, `#D5D7DA` border. Label 14px above; helper
or error text 14px below. Leading icons in gray-500 via `prefix` prop.

Focus → `#9AA8FF` border. Error → error-300 border + red focus ring. Do not
restore box-shadow on focus — it is intentionally removed.

---

## Checkbox / radio / toggle

16–20px. Checkbox radius: 4px (not 6px — 6px is off-spec). On-state: checkbox
`#1447E6` fill. Radio and toggle: brand-600 fill. Always include
`caret-color: auto` on input elements.

---

## Tag (rectangular badge)

12–14px, weight 500, radius 6px. Two variants:
- **Tinted** — `50` background, `200` border, `700` text. Use for risk-adjacent
  labels, role badges, status tags.
- **Modern** — white background, `#D5D7DA` border, gray-700 text. Use for neutral
  overflow counts.

Do not use radius 9999px on tags — that is the Pill variant. Do not use radius
24px — that is off-scale.

One tag family only. Do not use Generic Tag, Status_Tag, or Item Tag components —
these are deprecated MKV-era components.

---

## Pill (status)

Full radius (9999px), 12–14px, weight 500. Use for merchant status values:
Active (success), Invited (success tint), Blocked (error). Optional leading
status dot.

---

## Risk badge

The standard merchant risk treatment. Always an outlined pill — Critical / High /
Medium / Low — using the exact risk colors in `foundations/color.md`. Never show
risk as plain text or an emoji. Never use risk colors outside of risk context.

One risk badge component only. Do not use Risk_MKV — it is a deprecated
MKV-era component.

---

## Table — the backbone

Always use `<Table className="ant-g2-table" />`. Do not use `pagination` prop.
Pass `scroll={{ y: 'calc(100vh - var(--header-height) - var(--filters-height))' }}`.

- Header: `#FAFAFA` background, 12px semibold `#717680` headers in Title Case.
  Height 44px. First cell: 24px left padding.
- Rows: height 64px, `#E9EAEB` bottom border. Hover → `#FAFAFA`. Selected →
  `#E2E8FF` (brand-50).
- Header is sticky — stays visible as rows scroll.
- Sorting: sortable columns show `ChevronsUpDown` in gray-400 at rest. Active
  sort shows directional chevron in `#2C28E6`. Descending rotates the icon via
  CSS — do not swap icons manually.
- Lazy loading: fetch next page as user nears the bottom. Show a centered
  brand-600 spinner in the table body while loading. No pagination controls.
- Leading checkbox column optional (brand-50 fill when selected).
- Inline cell content: risk badge, category chips with `+N` overflow, name only
  (no avatar) in Merchant Assignee, progress bar, trailing `MoreVertical` icon.

---

## Progress bar

Full radius track in `#E9EAEB`, brand-600 fill, turns `#079455` green at 100%,
trailing `%` label. Used for Review Status column.

---

## Card

White, 16px radius, sm shadow, 24px padding. Optional header: title (18px/600) +
subtitle (14px gray-500) + actions. Header height is padding-driven (24px top +
content) — not fixed at 98px. Do not add colored left borders or gradient fills.

---

## Modal

Use `<Modal className="ant-g2-modal" />`. Centered, 16px radius, 2xl shadow,
`rgba(10,13,18,.55)` overlay with slight blur. Featured icon (tinted circle) +
18px/600 title + 14px gray-600 body + two footer buttons (secondary-gray +
primary, full-width split). Close button 18px from top-right edges.

---

## Drawer

Slides in from the right (~70vw), 2xl shadow. Header: merchant name + IDs + risk
+ status badges. Body is tabbed: Findings, Merchant Details, Audit, Team.
The drawer overlays the table — it is not a route change. The table remains
mounted behind the overlay. No Notifications tab — toasts handle system messages.

---

## Toast

Toasts are the only system feedback mechanism. Use Ant Design `notification` API
with G2RS notification overrides from `antd.css`. Width 300px, padding 18px,
radius 12px.

- Position: top-right.
- Success: `CheckCircle` icon in success-600, success-50 background.
- Error: `AlertTriangle` icon in error-600, error-50 background.
- Copy: terse, action-confirming. "Merchant saved." "Export failed — try again."
  Sentence case. No exclamation marks.
- Do not use inline banners, alert bars, or notification panels. Toasts only.

---

## Tabs

Use `<Tabs />` from antd. Active tab: `#1B43B7` text + 2px `#1B43B7` underline.
Inactive: `#717680`. One tab component only — do not use `Tab item`, `Tabs`
(legacy), or the 6-variant `Horizontal Tabs` set. Use `Horizontal tabs` (40
variants) as the canonical component.

---

## Tooltip / help icon

Use for field-level explanations and column header help (e.g. Review Status `?`).
Icon: `HelpCircle` from Lucide, 16px, gray-400. Tooltip appears on hover:
white background, 8px radius, sm shadow, 14px gray-700 text, max-width 240px.
Position: top, no arrow (top-no-arrow variant). Do not use tooltips for error
messages — use inline helper text below the field instead.

---

## Avatar / avatar label group

Circular, full radius. Sizes: 24px (table inline), 32px (default), 40px (profile).
Show initials (2 characters, uppercase) when no photo is available. Initials
background uses a consistent color derived from the user's name — do not randomize.
Do not show avatars in the Merchant Assignee table column — name only. Avatars
appear in: app bar (current user), user management table, drawer team tab.

Avatar label group: avatar + name (14px/500) + optional supporting text
(12px gray-500) in a horizontal row, gap 8px.

---

## Left-nav list item

Used in settings and configuration screens with a persistent side navigation.
Height 40px, 8px radius, 16px horizontal padding (symmetric). Icon 20px +
label 14px/500, gap 12px.

- Default: transparent background, gray-700 text, gray-500 icon.
- Hover: `#F5F5F5` background.
- Active: `#EFF8FF` background, brand-700 text, brand-600 icon. Do not use
  `#EFF6FF` — it is an off-palette near-duplicate.

---

## Step / progress steps

Used in multi-step flows (New Merchant, New User). Full radius step indicators.

- Complete: brand-600 filled circle, white checkmark.
- Current: brand-600 outlined circle, brand-600 step number.
- Incomplete: gray-200 filled circle, gray-500 step number.

Label below each step: 12px/500. Current step label: brand-700. Do not use
progress bars for multi-step flows — use step indicators.

---

## File upload

Dropzone + file item rows. Dropzone: white background, `#D5D7DA` dashed border
2px, 8px radius, 24px padding, centered `Upload` icon (gray-400) + 14px/500
label + 12px gray-500 supporting text. Accepts CSV and document formats.

File item row: `CheckCircle` or `AlertTriangle` icon + filename (14px/500) +
file size (12px gray-500) + progress bar or error state + `X` dismiss button.
Error state: error-50 background, error-600 text, `AlertTriangle` icon.

---

## Featured icon

An icon in a tinted circle or square (light, outline-ring, or modern white), in
brand / gray / error / warning / success. Used in modals and empty states.

---

## Empty state

Centered: gray modern featured icon + 16px/600 title + 14px gray-500 supporting
text + primary action button. Use when a table or list has no results.

---

## App bar

Sticky, white, 1px `#E9EAEB` bottom border, height `var(--header-height)` (64px).
Left: G2RS logo lockup. Right: user name + role badge + context line
(e.g. "Adyen • High Risk Merchants") + icon buttons (Download, Settings).

The app bar can contain a tab navigation row below the main bar, using the
underline tab style with brand-700 active state and brand-600 2px underline.