# Voice, Motion & States

## Voice & copy

Write professional, terse, operational copy. Favor clarity over warmth. No
marketing fluff in-app, no exclamation marks.

- Buttons are verb-first: "Add merchant", "Add", "Export", "Apply", "View evidence".
- Use Title Case for table headers, filters, and primary buttons. Use sentence
  case for helper text.
- Make counts explicit: "7 Merchants", "+4".

Use these domain nouns exactly: Merchant, Portfolio, Finding, Risk Level, Review
Status, Category, MID / MCC / CMK, Merchant Assignee, Merchant Status, Scan,
Monitoring On/Off.

## Loading states

Use a centered brand-600 spinner for all loading states. Place it horizontally
and vertically centered in the container it belongs to — the table body, a card,
or the full page.

Do not use skeleton screens or placeholder layouts. One pattern only: centered
spinner.

## Motion

Use 120–160ms ease on hover, press, and progress-width changes; opacity and
background fades. The one defined keyframe is `fade-in` (opacity 0→1, 120ms
ease) — use it for elements appearing on the page. No bounce. No decorative or
looping animation.

## Interaction states

- **Hover** — primary darkens 600→700; secondary and ghost get a `#F9F9F9` wash;
  table rows go to `#FAFAFA`.
- **Pressed / active** — selected tab fills with brand underline; selected row
  is brand-50.
- **Focus** — `0 0 0 4px rgba(20,71,230,.24)` ring. Red ring on error fields.
- **Disabled** — opacity 0.5 on primary buttons; gray-100 fill / gray-400 text
  on others. No shadow.
- **Selected row** — brand-50 background (`#E2E8FF`).

## Do / Don't

**Do:** white cards on `#F8F9FD`; meaningful color only; Inter via
`font-variation-settings`; 8/12/16px radii; soft neutral shadows; outlined risk
pills; Title Case headers; Lucide icons from `lucide-react`.

**Don't:** gradient backgrounds on in-app chrome; colored or heavy shadows; emoji;
purple as a brand color; rounded cards with colored left borders; UI text below
14px; decorative animation; `font-weight` instead of `font-variation-settings`;
`@ant-design/icons` for UI icons; Tailwind classes; inline styles.