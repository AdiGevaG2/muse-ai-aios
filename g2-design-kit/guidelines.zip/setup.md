# G2RS — Project Setup

Read this file before writing any code. It defines how G2RS loads its styles,
what component library to use, the layout model of the application, and the
token quirks that will silently break output if ignored.

---

## Stack

- **Framework:** React (Ant Design component library — `antd`)
- **Styling:** Plain CSS with CSS custom properties (no Tailwind, no CSS modules,
  no styled-components)
- **Build system:** Vite

Do not use Tailwind utility classes. Do not import shadcn/ui. Do not use inline
styles. All styling is done through CSS custom properties and Ant Design class
overrides.

---

## Ant Design theme configuration — CRITICAL, read first

Every generated screen must wrap its root in a `ConfigProvider` with the G2RS
theme. This is the single most important rule in this file.

**Why this matters:** antd injects its own color system (`colorPrimary: #1677FF`)
at a specificity level that beats any CSS override. Chat instructions about colors
cannot override this. CSS classes cannot reliably override this. Only
`ConfigProvider` can set antd's colors correctly. Without it, buttons render in
antd's default blue, secondary buttons render in antd's default gray, and no
amount of CSS patching will fix it reliably.

Import the theme constant from `src/theme.ts`:

```tsx
import { ConfigProvider } from 'antd';
import { g2rsTheme } from './theme';

export default function App() {
  return (
    <ConfigProvider theme={g2rsTheme}>
      {/* screen content */}
    </ConfigProvider>
  );
}
```

The `g2rsTheme` constant lives in `src/theme.ts`:

```tsx
import type { ThemeConfig } from 'antd';

export const g2rsTheme: ThemeConfig = {
  token: {
    colorPrimary: '#1447E6',
    colorPrimaryHover: '#1B43B7',
    colorPrimaryActive: '#193A88',
    colorPrimaryBorder: '#9AA8FF',
    borderRadius: 8,
    borderRadiusLG: 16,
    borderRadiusSM: 6,
    colorBorder: '#D5D7DA',
    colorBorderSecondary: '#E9EAEB',
    colorText: '#181D27',
    colorTextSecondary: '#414651',
    colorTextTertiary: '#535862',
    colorTextPlaceholder: '#717680',
    colorBgContainer: '#FFFFFF',
    colorBgLayout: '#F8F9FD',
    colorBgElevated: '#FFFFFF',
    colorError: '#D92D20',
    colorSuccess: '#079455',
    colorWarning: '#DC6803',
    fontFamily: 'Inter, system-ui, sans-serif',
    fontSize: 14,
    lineHeight: 1.4286,
    controlHeight: 36,
  },
  components: {
    Button: {
      defaultBorderColor: '#D5D7DA',
      defaultColor: '#414651',
      defaultBg: '#FFFFFF',
      defaultHoverBorderColor: '#D5D7DA',
      defaultHoverColor: '#181D27',
      defaultHoverBg: '#F9F9F9',
      defaultActiveBorderColor: '#D5D7DA',
      defaultActiveColor: '#181D27',
      defaultActiveBg: '#F5F5F5',
      primaryColor: '#FFFFFF',
      fontWeight: 600,
      borderRadius: 8,
      controlHeight: 36,
      paddingInline: 16,
    },
    Input: {
      borderRadius: 8,
      controlHeight: 36,
      colorBorder: '#D5D7DA',
      hoverBorderColor: '#9AA8FF',
      activeBorderColor: '#9AA8FF',
      activeShadow: '0 0 0 4px rgba(20,71,230,.24)',
      colorTextPlaceholder: '#717680',
    },
    Select: {
      borderRadius: 8,
      controlHeight: 36,
      colorBorder: '#D5D7DA',
      optionSelectedBg: '#E2E8FF',
      optionSelectedColor: '#1447E6',
    },
    Table: {
      borderRadius: 12,
      headerBg: '#FAFAFA',
      headerColor: '#717680',
      headerSortActiveBg: '#FAFAFA',
      rowHoverBg: '#FAFAFA',
      rowSelectedBg: '#E2E8FF',
      rowSelectedHoverBg: '#D0DAFF',
      cellPaddingBlock: 16,
      cellPaddingInline: 24,
    },
    Modal: {
      borderRadiusLG: 16,
      paddingContentHorizontalLG: 24,
    },
    Tabs: {
      inkBarColor: '#1447E6',
      itemActiveColor: '#1B43B7',
      itemSelectedColor: '#1B43B7',
      itemHoverColor: '#1447E6',
      itemColor: '#717680',
    },
    Checkbox: {
      borderRadiusSM: 4,
      colorPrimary: '#1447E6',
      colorPrimaryHover: '#1B43B7',
    },
    Switch: {
      colorPrimary: '#1447E6',
      colorPrimaryHover: '#1B43B7',
    },
    Notification: {
      borderRadiusLG: 12,
      width: 300,
    },
  },
};
```

Do not redefine theme tokens inline per screen. Always import from `src/theme.ts`.

---

## CSS imports

The app loads styles in this exact order. Replicate this in any generated file:

```css
@import url(./fonts.css);
@import url(./variables.css);
@import url(./colors.css);
@import url(./animations.css);
@import url(./antd.css);
```

For prototyping in Make (where local font files are unavailable), load Inter from
Google Fonts instead:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
  rel="stylesheet"
/>
```

Then apply globally:

```css
* {
  font-family: Inter, sans-serif !important;
  box-sizing: border-box;
}
```

---

## Token format — read this before using any value

All CSS custom properties are defined on `:root`. Values are always in `px` —
never unitless. Use them as `var(--token-name)` in CSS declarations.

```css
/* Correct */
padding: var(--header-height);

/* Wrong — don't hardcode values that have tokens */
padding: 64px;
```

**Layout tokens** (from `variables.css`):

| Token | Value | Use |
|---|---|---|
| `--header-height` | `64px` | App bar / top nav height |
| `--filters-height` | `52px` | Filter/toolbar row height |
| `--table-row-height` | `44px` | Table row height (standard rows) |

**Color tokens** (from `colors.css`) — see `foundations/color.md` for the full
table. The tokens most likely to be needed in generated code:

| Token | Value | Use |
|---|---|---|
| `--color-text-primary-900` | `#181D27` | Primary body text |
| `--color-text-secondary-700` | `#414651` | Secondary text |
| `--color-text-tertiary-600` | `#535862` | Tertiary / table cell text |
| `--color-text-quaternary` | `#717680` | Muted / placeholder text |
| `--color-border-primary` | `#D5D7DA` | Strong borders |
| `--color-border-secondary` | `#E9EAEB` | Subtle borders / dividers |

**Shadow composite syntax** — always write as a single `box-shadow` declaration:

```css
/* Dropdown / popover shadow */
box-shadow:
  0px 2px 2px -1px rgba(10, 13, 18, 0.04),
  0px 4px 6px -2px rgba(10, 13, 18, 0.03),
  0px 12px 16px -4px rgba(10, 13, 18, 0.08);

/* Modal shadow */
box-shadow: 0 24px 48px -12px rgba(10, 13, 18, 0.18);

/* Button / input resting shadow */
box-shadow: 0 1px 2px rgba(10, 13, 18, 0.05);
```

Never split shadow tokens across multiple properties. Never use colored shadows.

---

## Ant Design component classes

G2RS overrides antd components with custom CSS classes. Apply the G2RS class
alongside the antd component. The ConfigProvider handles colors; the CSS class
handles layout and structural overrides.

| Component | G2RS class | What it does |
|---|---|---|
| Button | `ant-g2-button` | Sets height 36px, padding 16px, removes box-shadow |
| Input | `ant-g2-input` | Sets height 36px, 8px radius, G2RS border colors |
| Select | `ant-g2-select` | Sets height 36px, 8px radius, G2RS border/arrow colors |
| Table | `ant-g2-table` | Full G2RS table treatment — headers, row height, sorting |
| Modal | `ant-g2-modal` | 16px radius, 24px padding, G2RS close button position |

Example — primary button:

```tsx
<Button type="primary" variant="solid" className="ant-g2-button">
  Add merchant
</Button>
```

Example — secondary button:

```tsx
<Button type="default" variant="outlined" className="ant-g2-button">
  Cancel
</Button>
```

Example — icon button (frameless — no wrapping div, no background at rest):

```tsx
<Button
  type="text"
  className="ant-g2-button"
  icon={<Settings size={16} />}
/>
```

Icon buttons are frameless. No background, no border, no wrapping container at
rest. Transparent background, `#F5F5F5` on hover only. Do not wrap icon buttons
in a div or card frame.

Example — G2RS input:

```tsx
<Input
  className="ant-g2-input"
  prefix={<Search size={16} />}
  placeholder="Search merchants"
/>
```

Example — G2RS table:

```tsx
<Table
  className="ant-g2-table"
  columns={columns}
  dataSource={data}
  scroll={{ y: 'calc(100vh - var(--header-height) - var(--filters-height))' }}
/>
```

---

## Layout model — critical

The application is **fixed-height** (`overflow: hidden` on `body`). The page
does not scroll. Scroll happens only inside the table body.

The shell structure of every G2RS screen:

```
┌─────────────────────────────────────────────────────┐
│  App bar (sticky, height: var(--header-height))      │
├─────────────────────────────────────────────────────┤
│  Filter / toolbar row (height: var(--filters-height))│
├─────────────────────────────────────────────────────┤
│  Table (flex: 1, scroll: vertical only, y fills      │
│  remaining viewport)                                 │
└─────────────────────────────────────────────────────┘
```

Implement with a flex column that fills the viewport:

```css
.page-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
  background: #f8f9fd;
}

.page-content {
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
}
```

The table receives `scroll={{ y: 'calc(100vh - var(--header-height) - var(--filters-height))' }}`
so it fills exactly the remaining space. Do not use `overflow: auto` on the outer
page container — the table manages its own scroll internally.

---

## Icons

Import from `@iconscout/react-unicons` only. Never use `@ant-design/icons` for UI elements.

```tsx
import UilSearch from '@iconscout/react-unicons/icons/uil-search';
import UilPlus from '@iconscout/react-unicons/icons/uil-plus';
import UilAngleDown from '@iconscout/react-unicons/icons/uil-angle-down';
import UilSetting from '@iconscout/react-unicons/icons/uil-setting';
import UilImport from '@iconscout/react-unicons/icons/uil-import';
```

Render at 16px in most UI contexts. Use `currentColor` so they inherit text color.

---

## Animations

One animation is defined globally: `fade-in` (opacity 0→1). Use it for elements
that appear on the page:

```css
animation: fade-in 120ms ease;
```

No additional keyframe animations. No bounce, spring, or looping animations.
Motion timing is 120–160ms ease for all transitions.

---

## Known quirks — do not violate these

- `font-variation-settings: 'wght' 600` sets Inter semibold — not `font-weight: 600`.
- `caret-color: transparent` is set globally. Always restore with `caret-color: auto`
  on `input` and `textarea` elements.
- Do not use `pagination` prop on Table — G2RS uses lazy loading only.
- Box-shadow on antd inputs and selects is intentionally removed on focus.
  Do not restore it.
- The primary brand color is `#1447E6`. Not `#000457` (legacy navy), not
  `#1677FF` (antd default). The ConfigProvider enforces this — do not override it.