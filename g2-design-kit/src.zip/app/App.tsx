/**
 * G2RS — Merchant Table Screen
 *
 * Icons: @iconscout/react-unicons (Uil prefix, imported by path).
 *        Never lucide-react or @ant-design/icons.
 * Colors: ConfigProvider(g2rsTheme) is the authority.
 * CSS: structure and layout only.
 */

// Suppress the ReactDOM.render warning produced by the Make preview harness
// (figma:foundry-client-api). That call is outside this codebase. This patch
// runs before the harness renders the component because the harness first
// imports this module, then calls ReactDOM.render with the exported component.
(() => {
  const orig = console.error.bind(console);
  console.error = (...args: Parameters<typeof console.error>) => {
    if (
      typeof args[0] === "string" &&
      args[0].includes("ReactDOM.render is no longer supported")
    )
      return;
    orig(...args);
  };
})();

import { useState } from "react";
import { ConfigProvider, Table, Input, Select, Button } from "antd";
import type { TableColumnsType } from "antd";

// Icons — Unicons line style, Uil prefix, imported by path
import UilSearch from "@iconscout/react-unicons/icons/uil-search";
import UilPlus from "@iconscout/react-unicons/icons/uil-plus";
import UilAngleDown from "@iconscout/react-unicons/icons/uil-angle-down";
import UilSetting from "@iconscout/react-unicons/icons/uil-setting";
import UilImport from "@iconscout/react-unicons/icons/uil-import";
import UilFilter from "@iconscout/react-unicons/icons/uil-filter";
import UilEllipsisV from "@iconscout/react-unicons/icons/uil-ellipsis-v";
import UilQuestionCircle from "@iconscout/react-unicons/icons/uil-question-circle";

import { g2rsTheme } from "../theme";
import "./App.css";

// ─── Types ───────────────────────────────────────────────────────────────────

type RiskLevel = "Critical" | "High" | "Medium" | "Low";

interface Category {
  name: string;
  color: string;
}

interface MerchantRow {
  key: string;
  name: string;
  mid: string;
  mcc: string;
  mccDesc: string;
  riskLevel: RiskLevel;
  categories: Category[];
  assigneeName: string;
  findings: number;
  reviewPercent: number;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const MERCHANTS: MerchantRow[] = [
  {
    key: "1",
    name: "Pharma Plus Direct",
    mid: "4891230",
    mcc: "5912",
    mccDesc: "Drug Stores And Pharmacies",
    riskLevel: "Critical",
    categories: [
      { name: "Drug Stores", color: "blue" },
      { name: "Nutraceuticals", color: "purple" },
    ],
    assigneeName: "Sarah Chen",
    findings: 12,
    reviewPercent: 85,
  },
  {
    key: "2",
    name: "Vintage Spirits Co.",
    mid: "7234561",
    mcc: "5921",
    mccDesc: "Package Stores — Beer, Wine And Liquor",
    riskLevel: "High",
    categories: [
      { name: "Alcohol", color: "orange-dark" },
      { name: "Tobacco", color: "orange" },
    ],
    assigneeName: "Marcus Webb",
    findings: 7,
    reviewPercent: 60,
  },
  {
    key: "3",
    name: "GreenLeaf CBD",
    mid: "5673892",
    mcc: "5999",
    mccDesc: "Miscellaneous And Specialty Retail",
    riskLevel: "High",
    categories: [
      { name: "CBD Oil", color: "green" },
      { name: "Supplements", color: "blue-light" },
      { name: "Organic", color: "success" },
    ],
    assigneeName: "Priya Sharma",
    findings: 4,
    reviewPercent: 40,
  },
  {
    key: "4",
    name: "SwiftBet Gaming",
    mid: "3345678",
    mcc: "7993",
    mccDesc: "Video Amusement Game Supplies",
    riskLevel: "Critical",
    categories: [
      { name: "Gambling", color: "indigo" },
      { name: "Online Gaming", color: "indigo" },
      { name: "Fantasy Sports", color: "blue" },
    ],
    assigneeName: "Alex Torres",
    findings: 31,
    reviewPercent: 20,
  },
  {
    key: "5",
    name: "VitaCore Labs",
    mid: "8901234",
    mcc: "5122",
    mccDesc: "Drugs, Drug Proprietaries And Druggists",
    riskLevel: "Medium",
    categories: [
      { name: "Nutraceuticals", color: "purple" },
      { name: "Health & Wellness", color: "success" },
    ],
    assigneeName: "Jordan Kim",
    findings: 2,
    reviewPercent: 100,
  },
  {
    key: "6",
    name: "Coastal Firearms LLC",
    mid: "2156890",
    mcc: "5941",
    mccDesc: "Sporting Goods Stores And Bicycle Shops",
    riskLevel: "Low",
    categories: [
      { name: "Weapons", color: "orange-dark" },
      { name: "Ammunition", color: "orange" },
    ],
    assigneeName: "Dana Park",
    findings: 0,
    reviewPercent: 15,
  },
  {
    key: "7",
    name: "QuickFX Trading",
    mid: "6078341",
    mcc: "6211",
    mccDesc: "Security Brokers And Dealers",
    riskLevel: "Medium",
    categories: [
      { name: "Forex", color: "blue" },
      { name: "Derivatives", color: "indigo" },
      { name: "Commodities", color: "orange" },
    ],
    assigneeName: "Reese Morgan",
    findings: 9,
    reviewPercent: 72,
  },
];

const DATE_OPTIONS = [
  { label: "This week", value: "week" },
  { label: "This month", value: "month" },
  { label: "Last 30 days", value: "30d" },
  { label: "Custom range", value: "custom" },
];
const RISK_OPTIONS = [
  { label: "Critical", value: "Critical" },
  { label: "High", value: "High" },
  { label: "Medium", value: "Medium" },
  { label: "Low", value: "Low" },
];
const CATEGORY_OPTIONS = [
  { label: "Drug Stores", value: "drug" },
  { label: "Alcohol", value: "alcohol" },
  { label: "CBD Oil", value: "cbd" },
  { label: "Gambling", value: "gambling" },
  { label: "Nutraceuticals", value: "nutra" },
];
const STATUS_OPTIONS = [
  { label: "Active", value: "active" },
  { label: "Invited", value: "invited" },
  { label: "Blocked", value: "blocked" },
];

// ─── Cell components ──────────────────────────────────────────────────────────

function RiskBadge({ level }: { level: RiskLevel }) {
  return (
    <span className={`g2rs-risk-badge g2rs-risk-badge--${level.toLowerCase()}`}>
      {level}
    </span>
  );
}

const MAX_CHIPS = 2;

function CategoryChipList({ categories }: { categories: Category[] }) {
  const shown = categories.slice(0, MAX_CHIPS);
  const overflow = categories.length - MAX_CHIPS;
  return (
    <div className="g2rs-category-chips">
      {shown.map((cat) => (
        <span
          key={cat.name}
          className={`g2rs-category-chip g2rs-category-chip--${cat.color}`}
        >
          {cat.name}
        </span>
      ))}
      {overflow > 0 && (
        <span className="g2rs-category-chip g2rs-category-chip--overflow">
          +{overflow}
        </span>
      )}
    </div>
  );
}

function ReviewProgress({ percent }: { percent: number }) {
  const clamped = Math.min(percent, 100);
  const isComplete = percent >= 100;
  return (
    <div className="g2rs-review-progress">
      <div className="g2rs-review-progress__track">
        {/*
          using <div> instead of antd Progress: kit spec requires 8px track
          height and CSS-token fill; antd Progress track height is not
          configurable without CSS-in-JS incompatible with this kit's CSS arch
        */}
        <div
          className={`g2rs-review-progress__fill${isComplete ? " g2rs-review-progress__fill--complete" : ""}`}
          style={{ "--pct": `${clamped}%` } as React.CSSProperties}
        />
      </div>
      <span className="g2rs-review-progress__label">{percent}%</span>
    </div>
  );
}

// ─── Table columns ────────────────────────────────────────────────────────────

const columns: TableColumnsType<MerchantRow> = [
  {
    title: "Merchant Name",
    key: "name",
    sorter: (a, b) => a.name.localeCompare(b.name),
    showSorterTooltip: false,
    render: (_, r) => (
      <div className="g2rs-merchant-name-cell">
        <span className="g2rs-merchant-name-cell__title">{r.name}</span>
        {/* 12px sub-label — 13px is off-scale per type-and-layout.md */}
        <span className="g2rs-merchant-name-cell__meta">
          {r.mid} • {r.mcc} — {r.mccDesc}
        </span>
      </div>
    ),
  },
  {
    title: "Risk Level",
    key: "riskLevel",
    width: 128,
    sorter: (a, b) => {
      const order: Record<RiskLevel, number> = {
        Critical: 0, High: 1, Medium: 2, Low: 3,
      };
      return order[a.riskLevel] - order[b.riskLevel];
    },
    showSorterTooltip: false,
    render: (_, r) => <RiskBadge level={r.riskLevel} />,
  },
  {
    title: "Categories",
    key: "categories",
    width: 220,
    render: (_, r) => <CategoryChipList categories={r.categories} />,
  },
  {
    title: "Merchant Assignee",
    key: "assignee",
    width: 168,
    sorter: (a, b) => a.assigneeName.localeCompare(b.assigneeName),
    showSorterTooltip: false,
    // Name only — no avatar per components.md Avatar section
    render: (_, r) => (
      <span className="g2rs-assignee-name">{r.assigneeName}</span>
    ),
  },
  {
    title: "Findings",
    key: "findings",
    width: 100,
    sorter: (a, b) => a.findings - b.findings,
    showSorterTooltip: false,
    render: (_, r) => (
      <span className="g2rs-findings-count">{r.findings}</span>
    ),
  },
  {
    title: (
      <span className="g2rs-col-header">
        Review Status
        {/*
          UilQuestionCircle — Unicons equivalent of HelpCircle tooltip trigger.
          type-and-layout.md: "Use Unicons line style only. Never lucide-react."
        */}
        <UilQuestionCircle
          size={14}
          color="var(--component-colors\/utility\/gray\/utility-gray-400)"
        />
      </span>
    ),
    key: "reviewStatus",
    width: 200,
    sorter: (a, b) => a.reviewPercent - b.reviewPercent,
    showSorterTooltip: false,
    render: (_, r) => <ReviewProgress percent={r.reviewPercent} />,
  },
  {
    title: "",
    key: "actions",
    width: 52,
    render: () => (
      <Button
        type="text"
        className="ant-g2-button g2rs-row-action"
        icon={
          <UilEllipsisV size={15} color="currentColor" />
        }
        aria-label="Row actions"
      />
    ),
  },
];

// ─── App ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);

  return (
    /*
      ConfigProvider MUST be the outermost antd wrapper.
      It injects colorPrimary: #1447E6 into antd's CSS-in-JS token system —
      the only reliable way to override antd's default #1677FF.
    */
    <ConfigProvider theme={g2rsTheme}>
      <div className="g2rs-screen">
        {/* MARKER-MAKE-KIT-INVOKED */}
        {/* MARKER-MAKE-KIT-DISCOVERY-READ */}
        {/* MARKER-MAKE-KIT-TOKENS-READ */}
        {/* MARKER-MAKE-KIT-FINAL-CHECK-READ */}

        {/* ── App Bar ─────────────────────────────────────────────────── */}
        <header className="g2rs-app-bar">
          <div className="g2rs-app-bar__left">
            <div className="g2rs-logo-mark" aria-hidden="true" />
            <span className="g2rs-logo-wordmark">G2RS</span>
          </div>

          <div className="g2rs-app-bar__right">
            <span className="g2rs-app-bar-context">
              Adyen • High Risk Merchants
            </span>
            <div className="g2rs-app-bar-divider" aria-hidden="true" />
            <div className="g2rs-app-bar-user">
              <span className="g2rs-app-bar-user__name">Emma Rodriguez</span>
              <span className="g2rs-role-tag">Senior Analyst</span>
            </div>

            {/*
              Icon buttons — type="text", frameless per setup.md + components.md.
              Icons: UilImport (download/export), UilSetting (settings).
              color="currentColor" inherits the button's text color.
            */}
            <Button
              type="text"
              className="ant-g2-button"
              icon={<UilImport size={16} color="currentColor" />}
              aria-label="Export"
            />
            <Button
              type="text"
              className="ant-g2-button"
              icon={<UilSetting size={16} color="currentColor" />}
              aria-label="Settings"
            />
          </div>
        </header>

        {/* ── Filter / Toolbar Row ─────────────────────────────────────
            All three button types visible for verification:
              Primary   — "+ Add"  type="primary" variant="solid"
              Secondary — "More"   type="default" variant="outlined"
              Icon ×2   — Filter, Export  type="text" (frameless)
        ─────────────────────────────────────────────────────────────── */}
        <div className="g2rs-filter-row">
          <div className="g2rs-filter-search">
            <Input
              className="ant-g2-input"
              prefix={<UilSearch size={15} color="var(--color-text-quaternary)" />}
              placeholder="Legal name or URL"
              allowClear
            />
          </div>

          <div className="g2rs-filter-select-wrap g2rs-filter-select-wrap--date">
            <Select
              className="ant-g2-select"
              options={DATE_OPTIONS}
              placeholder="Creation Date"
              allowClear
            />
          </div>
          <div className="g2rs-filter-select-wrap g2rs-filter-select-wrap--risk">
            <Select
              className="ant-g2-select"
              options={RISK_OPTIONS}
              placeholder="Merchant Risk"
              allowClear
            />
          </div>
          <div className="g2rs-filter-select-wrap g2rs-filter-select-wrap--cat">
            <Select
              className="ant-g2-select"
              options={CATEGORY_OPTIONS}
              placeholder="Category"
              allowClear
            />
          </div>
          <div className="g2rs-filter-select-wrap g2rs-filter-select-wrap--status">
            <Select
              className="ant-g2-select"
              options={STATUS_OPTIONS}
              placeholder="Merchant Status"
              allowClear
            />
          </div>

          {/* Secondary button */}
          <Button
            type="default"
            variant="outlined"
            className="ant-g2-button"
            icon={<UilAngleDown size={14} color="currentColor" />}
            iconPosition="end"
          >
            More
          </Button>

          <div className="g2rs-filter-divider" aria-hidden="true" />

          {/* Icon buttons (frameless) */}
          <Button
            type="text"
            className="ant-g2-button"
            icon={<UilFilter size={16} color="currentColor" />}
            aria-label="Filter options"
          />
          <Button
            type="text"
            className="ant-g2-button"
            icon={<UilImport size={16} color="currentColor" />}
            aria-label="Export"
          />

          <div className="g2rs-filter-spacer" />
          <span className="g2rs-filter-count">7 Merchants</span>

          {/* Primary button */}
          <Button
            type="primary"
            variant="solid"
            className="ant-g2-button"
            icon={<UilPlus size={15} color="currentColor" />}
          >
            Add
          </Button>
        </div>

        {/* ── Table ─────────────────────────────────────────────────── */}
        <div className="g2rs-content">
          <div className="g2rs-table-section">
            <Table<MerchantRow>
              className="ant-g2-table"
              columns={columns}
              dataSource={MERCHANTS}
              rowKey="key"
              rowSelection={{
                selectedRowKeys,
                onChange: (keys) => setSelectedRowKeys(keys),
              }}
              pagination={false}
              scroll={{
                y: "calc(100vh - var(--header-height) - var(--filters-height))",
              }}
            />
          </div>
        </div>
      </div>
    </ConfigProvider>
  );
}
